package org.example.Presentation;

import org.example.BusinessLogic.Abstract_BLL;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Order_View extends JFrame {

    private JScrollPane sp;
    private JTable table;
    private JButton place;
    private JButton modify;
    private JButton delete;
    private JLabel id;
    private JTextField idTF;
    private JLabel clientID;
    private JTextField clientTF;
    private JLabel productID;
    private JTextField productTF;
    private JLabel quantity;
    private JTextField quantityTF;
    private Abstract_BLL ab;

    public Order_View(Abstract_BLL ab) {
        this.ab = ab;
        initializeTable();

        place = new JButton ("Place Order");
        modify = new JButton ("Modify");
        delete = new JButton ("Delete ID");
        id = new JLabel ("Order ID:");
        idTF = new JTextField (5);
        clientID = new JLabel ("Client ID:");
        clientTF = new JTextField (5);
        productID = new JLabel ("Product ID:");
        productTF = new JTextField (5);
        quantity = new JLabel ("Quantity:");
        quantityTF = new JTextField (5);

        setPreferredSize (new Dimension(752, 430));
        setLayout (null);


        add(sp);
        add (place);
        add (modify);
        add (delete);
        add (id);
        add (idTF);
        add (clientID);
        add (clientTF);
        add (productID);
        add (productTF);
        add (quantity);
        add (quantityTF);

        sp.setBounds(35, 150, 685, 250);
        place.setBounds (150, 100, 110, 20);
        modify.setBounds (275, 100, 100, 20);
        delete.setBounds (390, 100, 100, 20);
        id.setBounds (30, 20, 80, 25);
        idTF.setBounds (95, 20, 100, 25);
        clientID.setBounds (235, 20, 80, 25);
        clientTF.setBounds (320, 20, 100, 25);
        productID.setBounds (450, 20, 85, 20);
        productTF.setBounds (550, 20, 100, 25);
        quantity.setBounds (235, 55, 85, 25);
        quantityTF.setBounds (320, 55, 100, 25);

        setTitle("Order");
        pack();
        setVisible(true);
    }

    public void initializeTable() {
        String[] collumnNames = ab.getColumns();
        String[][] tableData = ab.getValues();
        table = new JTable (new DefaultTableModel(tableData, collumnNames));
        table.setModel(new DefaultTableModel(tableData, collumnNames));
        sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    public void refresh(){
        String[] collumnNames = ab.getColumns();
        String[][] tableData = ab.getValues();
        table.setModel(new DefaultTableModel(tableData, collumnNames));
    }
    private void enableTextFields(boolean enabled) {
        idTF.setEnabled(enabled);
        clientTF.setEnabled(enabled);
        productTF.setEnabled(enabled);
        quantityTF.setEnabled(enabled);
    }


    public String getID() {
        return idTF.getText();
    }
    public String getClientID() {
        return clientTF.getText();
    }
    public String getProductID() {
        return productTF.getText();
    }
    public String getQuantity() {
        return quantityTF.getText();
    }

    public void addAddListener(ActionListener a) {
        place.addActionListener(a);
    }
    public void addModifyListener(ActionListener a) {
        modify.addActionListener(a);
    }
    public void addDeleteListener(ActionListener a) {
        delete.addActionListener(a);
        delete.addMouseListener(new DeleteListener());
    }

    class DeleteListener implements MouseListener {
        public void mouseEntered(MouseEvent event)
        {
            enableTextFields(false);
        }
        public void mouseExited(MouseEvent event)
        {
            enableTextFields(true);
        }
        public void mousePressed(MouseEvent event) { }
        public void mouseReleased(MouseEvent event) { }
        public void mouseClicked(MouseEvent event) { }
    }
}
