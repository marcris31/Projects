package org.example.BusinessLogic;

import org.example.DataAccess.Client_DAO;
import org.example.Model.Client;

import java.util.List;
import java.util.NoSuchElementException;

public class Client_BLL extends Abstract_BLL {
    private final Client_DAO client_DAO;


    public Client_BLL() {
        client_DAO = new Client_DAO();
    }

    public List<Client> findAll() {
        List<Client> clientList = client_DAO.findAll();
        if (clientList == null) {
            throw new NoSuchElementException("No clients were found");
        }
        return client_DAO.findAll();
    }

    public Client findByID(int id) {
        Client c = client_DAO.findByID(id);
        if (c == null) {
            throw new NoSuchElementException("No client was found");
        }
        return c;
    }

    public void insertInto(Client c) {
        if (!isEligibleClient(c)) {
            throw new IllegalArgumentException("Not eligible client");
        }
        client_DAO.insertIntoTable(c);
    }

    public void update(Client c) {
        if (!isEligibleClient(c)) {
            throw new IllegalArgumentException("Not eligible client");
        }
        client_DAO.updateTable(c);
    }

    public void delete(int id) {
        Client c = client_DAO.findByID(id);
        if (c == null) {
            throw new IllegalArgumentException("Not eligible client");
        }
        client_DAO.deleteFromTable(id);
    }

    public String[] getColumns() {
        return client_DAO.getColumns();
    }

    public String[][] getValues() {
        try {
            return client_DAO.getValues();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isEligibleClient(Client c) {
        return c.getId() != 0 && c.getName().matches("[a-zA-Z]+") && c.getEmail().matches("[a-zA-Z0-9]+@[a-zA-Z]+\\.[a-zA-Z]+") && c.getAddress().matches("[a-zA-Z0-9]+") && c.getPhone().matches("^0[0-9]{9}$");
    }
}
