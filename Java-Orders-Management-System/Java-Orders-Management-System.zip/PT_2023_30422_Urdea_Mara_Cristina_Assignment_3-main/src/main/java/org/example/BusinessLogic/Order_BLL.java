package org.example.BusinessLogic;

import org.example.DataAccess.Order_DAO;
import org.example.DataAccess.Product_DAO;
import org.example.Model.Order;
import org.example.Model.Product;

import javax.swing.*;
import java.util.List;
import java.util.NoSuchElementException;

public class Order_BLL extends Abstract_BLL {

    private final Order_DAO order_DAO;

    public Order_BLL() {
        order_DAO = new Order_DAO();
    }

    public List<Order> findAll() {
        List<Order> orderList = order_DAO.findAll();
        if (orderList == null) {
            throw new NoSuchElementException("No orders were found");
        }
        return order_DAO.findAll();
    }

    public Order findByID(int id) {
        Order o = order_DAO.findByID(id);
        if (o == null) {
            throw new NoSuchElementException("No order was found");
        }
        return o;
    }

    public void insertInto(Order o) {
       /* if (!isEligibleOrder(o)) {
            throw new IllegalArgumentException("Not eligible order");
        }
        order_DAO.insertIntoTable(o);*/
        //Order_DAO order_DAO = new Order_DAO();
        Product_DAO product_DAO = new Product_DAO();
        int id = o.getId();
        //String prodid = String.valueOf(id);
        Product product = product_DAO.findByID(id);
        product.setStock(product.getStock() - o.getQuantity());
        if(product.getStock() < 0) {
            throw new IllegalArgumentException("Not enough stock");
        } else if (product.getStock() == 0) {
            product.setStock(0);
            product.setStock(0);
            product_DAO.updateTable(product);
            order_DAO.insertIntoTable(o);
        } else {
            product_DAO.updateTable(product);
            order_DAO.insertIntoTable(o);
        }
    }

    public void update(Order o) {
        if (!isEligibleOrder(o)) {
            throw new IllegalArgumentException("Not eligible order");
        }
        order_DAO.updateTable(o);
    }

    public void delete(int id) {
        Order o = order_DAO.findByID(id);
        if (o == null) {
            throw new IllegalArgumentException("Not eligible order");
        }
        order_DAO.deleteFromTable(id);
    }

    public String[] getColumns() {
        return order_DAO.getColumns();
    }

    public String[][] getValues() {
        try {
            return order_DAO.getValues();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isEligibleOrder(Order o) {
        boolean isEligible = true;
        Product_DAO product_DAO = new Product_DAO();
        isEligible = isEligible && (o.getId() != 0 && o.getQuantity() > 0 && o.getIdClient() > 0 && o.getIdProduct() > 0);

        try {
            isEligible = isEligible && (product_DAO.findByID(o.getIdProduct()).getStock() - o.getQuantity() >= 0);
        } catch (NullPointerException e) {
            e.printStackTrace();
            System.out.println("Not enough stock");
        }
        return isEligible;
    }
}
