package org.example.Presentation;
import org.example.BusinessLogic.Abstract_BLL;
import org.example.BusinessLogic.Client_BLL;
import org.example.BusinessLogic.Order_BLL;
import org.example.BusinessLogic.Product_BLL;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
public class MainMenu_View extends JFrame{
    private JButton client;
    private JButton product;
    private JButton order;
    private JLabel mainMenu;

    public MainMenu_View () {
        client = new JButton("CLIENT");
        product = new JButton("PRODUCT");
        order = new JButton("ORDER");
        mainMenu = new JLabel("MAIN MENU");

        setPreferredSize(new Dimension(752, 420));
        setLayout(null);

        add(client);
        add(product);
        add(order);
        add(mainMenu);

        client.setBounds(0, 145, 255, 105);
        product.setBounds(255, 145, 250, 105);
        order.setBounds(505, 145, 250, 105);
        mainMenu.setBounds(335, 30, 75, 30);

        setTitle("Main Menu");
        pack();
        setVisible(true);



    }
}
