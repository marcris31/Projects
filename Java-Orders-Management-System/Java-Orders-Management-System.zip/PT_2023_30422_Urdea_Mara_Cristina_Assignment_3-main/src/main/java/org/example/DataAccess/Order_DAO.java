package org.example.DataAccess;

import org.example.Model.Order;

public class Order_DAO extends Abstract_DAO<Order>{
}
