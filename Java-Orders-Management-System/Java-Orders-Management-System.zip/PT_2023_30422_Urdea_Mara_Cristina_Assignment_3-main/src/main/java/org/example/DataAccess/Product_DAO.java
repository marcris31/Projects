package org.example.DataAccess;

import org.example.Model.Product;

import java.util.List;

public class Product_DAO extends Abstract_DAO<Product> {
    public boolean exists(int id) {
        List< Product > productList = findAll();
        for (Product p: productList) {
            if (p.getId() == id) return true;
        }
        return false;
    }
}
