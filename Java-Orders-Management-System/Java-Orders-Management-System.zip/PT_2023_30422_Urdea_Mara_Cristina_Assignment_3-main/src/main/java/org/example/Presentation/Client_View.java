package org.example.Presentation;

import org.example.BusinessLogic.Abstract_BLL;
import org.example.BusinessLogic.Client_BLL;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Client_View extends JFrame{
    private JScrollPane sp;
    private JTable table;
    private JButton add;
    private JButton modify;
    private JButton delete;
    private JLabel id;
    private JTextField idTF;
    private JLabel name;
    private JTextField nameTF;
    private JLabel phone;
    private JTextField phoneTF;
    private JLabel email;
    private JTextField emailTF;
    private JLabel address;
    private JTextField addressTF;
    private Abstract_BLL ab;

    public Client_View(Abstract_BLL ab) {
        //construct preComponents
        this.ab = ab;
        initializeTable();

        add = new JButton ("Add");
        modify = new JButton ("Modify");
        delete = new JButton ("Delete ID");
        id = new JLabel ("Client ID:");
        idTF = new JTextField (5);
        name = new JLabel ("Client Name:");
        nameTF = new JTextField (5);
        phone = new JLabel ("Client Phone:");
        phoneTF = new JTextField (5);
        email = new JLabel ("Client Email:");
        emailTF = new JTextField (5);
        address = new JLabel ("Client Address:");
        addressTF = new JTextField (5);

        //adjust size and set layout
        setPreferredSize (new Dimension(752, 430));
        setLayout (null);

        //add components
        add (sp);
        add (add);
        add (modify);
        add (delete);
        add (id);
        add (idTF);
        add (name);
        add (nameTF);
        add (phone);
        add (phoneTF);
        add (email);
        add (emailTF);
        add (address);
        add (addressTF);

        //set component bounds (only needed by Absolute Positioning)
        sp.setBounds (35, 150, 685, 250);
        add.setBounds (160, 100, 100, 20);
        modify.setBounds (275, 100, 100, 20);
        delete.setBounds (390, 100, 100, 20);
        id.setBounds (30, 20, 80, 25);
        idTF.setBounds (95, 20, 100, 25);
        name.setBounds (235, 20, 80, 25);
        nameTF.setBounds (320, 20, 100, 25);
        phone.setBounds (450, 20, 85, 20);
        phoneTF.setBounds (550, 20, 100, 25);
        email.setBounds (235, 55, 85, 25);
        emailTF.setBounds (320, 55, 100, 25);
        address.setBounds (450, 55, 100, 25);
        addressTF.setBounds (550, 55, 100, 25);

        setTitle("Client");
        //setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    public void initializeTable() {
        String[] collumnNames = ab.getColumns();
        String[][] tableData = ab.getValues();
        table = new JTable (new DefaultTableModel(tableData, collumnNames));
        table.setModel(new DefaultTableModel(tableData, collumnNames));
        sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    public void refresh(){
        String[] collumnNames = ab.getColumns();
        String[][] tableData = ab.getValues();
        table.setModel(new DefaultTableModel(tableData, collumnNames));
    }
    private void enableTextFields(boolean enabled) {
        idTF.setEnabled(enabled);
        nameTF.setEnabled(enabled);
        phoneTF.setEnabled(enabled);
        emailTF.setEnabled(enabled);
        addressTF.setEnabled(enabled);
    }

    public String getID() {
        return idTF.getText();
    }
    public String getName() {
        return nameTF.getText();
    }
    public String getEmail() {
        return emailTF.getText();
    }
    public String getPhone() {return phoneTF.getText();}
    public String getAddress() {return addressTF.getText();}

    public void addAddListener(ActionListener a) {
        add.addActionListener(a);
    }
    public void addModifyListener(ActionListener a) {
        modify.addActionListener(a);
    }
    public void addDeleteListener(ActionListener a) {
        delete.addActionListener(a);
        delete.addMouseListener(new DeleteListener());
    }

    class DeleteListener implements MouseListener {
        public void mouseEntered(MouseEvent event)
        {
            enableTextFields(false);
        }
        public void mouseExited(MouseEvent event)
        {
            enableTextFields(true);
        }
        public void mousePressed(MouseEvent event) { }
        public void mouseReleased(MouseEvent event) { }
        public void mouseClicked(MouseEvent event) { }
    }
}
