package org.example.Presentation;

import org.example.BusinessLogic.Client_BLL;
import org.example.BusinessLogic.Order_BLL;
import org.example.BusinessLogic.Product_BLL;
import org.example.Model.Client;
import org.example.Model.Order;
import org.example.Model.Product;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.example.FileWriter.FileWriter;

import javax.swing.*;

public class Controller {
    Client_View cv;
    Client_BLL cb;
    Client c;

    Product_View pv;
    Product_BLL pb;

    Order_View cmv;
    Order_BLL cmb;

    public Controller() {
        c = new Client();

        cb = new Client_BLL();
        cv = new Client_View(cb);
        cv.addAddListener(new AddClientListener());
        cv.addModifyListener(new ModifyClientListener());
        cv.addDeleteListener(new DeleteClientListener());

        pb = new Product_BLL();
        pv = new Product_View(pb);
        pv.addAddListener(new AddProductListener());
        pv.addModifyListener(new ModifyProductListener());
        pv.addDeleteListener(new DeleteProductListener());

        cmb = new Order_BLL();
        cmv = new Order_View(cmb);
        cmv.addAddListener(new AddCommandListener());
        cmv.addModifyListener(new ModifyCommandListener());
        cmv.addDeleteListener(new DeleteCommandListener());
    }

    public class AddClientListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(cv.getID());
            String name = cv.getName();
            String phone = cv.getPhone();
            String address = cv.getAddress();
            String email = cv.getEmail();
            cb.insertInto(new Client(id, name, phone, address, email));

            cv.refresh();
        }
        */
        public void actionPerformed(ActionEvent e) {
            /*if (!cb.isEligibleClient(c)) {
                JOptionPane.showMessageDialog(null, "Please enter valid data. Phone number should start with 0 and have 10 digits. Email should contain @ and .");
                return;
            }*/
            String idText = cv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            String name = cv.getName();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid name.");
                return;
            }
            String phone = cv.getPhone();
            if (phone.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid phone number.");
                return;
            }
            String address = cv.getAddress();
            if (address.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid address.");
                return;
            }
            String email = cv.getEmail();
            if (email.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
                return;
            }
            cb.insertInto(new Client(id, name, phone, address, email));

            cv.refresh();
        }
    }
    public class ModifyClientListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(cv.getID());
            String name = cv.getName();
            String phone = cv.getPhone();
            String address = cv.getAddress();
            String email = cv.getEmail();
            cb.update(new Client(id, name, phone,  address, email));
            cv.refresh();
        }

        */
        public void actionPerformed(ActionEvent e) {
            String idText = cv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            String name = cv.getName();
            String phone = cv.getPhone();
            String address = cv.getAddress();
            String email = cv.getEmail();
            cb.update(new Client(id, name, phone,  address, email));
            cv.refresh();
        }
    }
    public class DeleteClientListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(cv.getID());
            cb.delete(id);
            cv.refresh();
        }

         */
        public void actionPerformed(ActionEvent e) {
            String idText = cv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            cb.delete(id);
            cv.refresh();
        }
    }

    public class AddProductListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(pv.getID());
            String name = pv.getName();
            int price = Integer.parseInt(pv.getPrice());
            int stock = Integer.parseInt(pv.getStock());
            pb.insertInto(new Product(id, name, price, stock));
            pv.refresh();
        }
        */
        public void actionPerformed(ActionEvent e) {
            String idText = pv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            String name = pv.getName();
            String priceText = pv.getPrice();
            if (priceText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid price.");
                return;
            }
            int price;
            try {
                price = Integer.parseInt(priceText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid price. Please enter a numeric value.");
                return;
            }

            String stockText = pv.getStock();
            if (stockText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid stock.");
                return;
            }
            int stock;
            try {
                stock = Integer.parseInt(stockText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid stock. Please enter a numeric value.");
                return;
            }
            pb.insertInto(new Product(id, name, price, stock));
            pv.refresh();
        }
    }
    public class ModifyProductListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(pv.getID());
            String name = pv.getName();
            int age = Integer.parseInt(pv.getPrice());
            int stock = Integer.parseInt(pv.getStock());
            pb.update(new Product(id, name, age, stock));
            pv.refresh();
        }
         */
        public void actionPerformed(ActionEvent e) {
            String idText = pv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            String name = pv.getName();
            String priceText = pv.getPrice();
            if (priceText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid price.");
                return;
            }
            int price;
            try {
                price = Integer.parseInt(priceText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid price. Please enter a numeric value.");
                return;
            }
            String stockText = pv.getStock();
            if (stockText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid stock.");
                return;
            }
            int stock;
            try {
                stock = Integer.parseInt(stockText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid stock. Please enter a numeric value.");
                return;
            }
            pb.update(new Product(id, name, price, stock));
            pv.refresh();
        }
    }
    public class DeleteProductListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(pv.getID());
            pb.delete(id);
            pv.refresh();
        }

         */
        public void actionPerformed(ActionEvent e) {
            String idText = pv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            pb.delete(id);
            pv.refresh();
        }
    }

    public class AddCommandListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(cmv.getID());
            int clientID = Integer.parseInt(cmv.getClientID());
            int productID = Integer.parseInt(cmv.getProductID());
            int quantity = Integer.parseInt(cmv.getQuantity());
            Order o = new Order(id, clientID, productID, quantity);
            FileWriter.createTxtBill(o);
            cmb.insertInto(o);
            cmv.refresh();
            pv.refresh();
        }

         */
        public void actionPerformed(ActionEvent e) {
            String idText = cmv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            String clientIDText = cmv.getClientID();
            if (clientIDText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid client ID.");
                return;
            }
            int clientID;
            try {
                clientID = Integer.parseInt(clientIDText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid client ID. Please enter a numeric value.");
                return;
            }
            String productIDText = cmv.getProductID();
            if (productIDText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid product ID.");
                return;
            }
            int productID;
            try {
                productID = Integer.parseInt(productIDText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid product ID. Please enter a numeric value.");
                return;
            }
            String quantityText = cmv.getQuantity();
            if (quantityText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid quantity.");
                return;
            }
            int quantity;
            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid quantity. Please enter a numeric value.");
                return;
            }
            Order o = new Order(id, clientID, productID, quantity);
            FileWriter.createTxtBill(o);
            cmb.insertInto(o);
            cmv.refresh();
            pv.refresh();
        }
    }
    public class ModifyCommandListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(cmv.getID());
            int clientID = Integer.parseInt(cmv.getClientID());
            int productID = Integer.parseInt(cmv.getProductID());
            int quantity = Integer.parseInt(cmv.getQuantity());
            cmb.update(new Order(id, clientID, productID, quantity));
            cmv.refresh();
        }

         */
        public void actionPerformed(ActionEvent e) {
            String idText = cmv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            String clientIDText = cmv.getClientID();
            if (clientIDText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid client ID.");
                return;
            }
            int clientID;
            try {
                clientID = Integer.parseInt(clientIDText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid client ID. Please enter a numeric value.");
                return;
            }
            String productIDText = cmv.getProductID();
            if (productIDText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid product ID.");
                return;
            }
            int productID;
            try {
                productID = Integer.parseInt(productIDText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid product ID. Please enter a numeric value.");
                return;
            }
            String quantityText = cmv.getQuantity();
            if (quantityText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid quantity.");
                return;
            }
            int quantity;
            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid quantity. Please enter a numeric value.");
                return;
            }
            cmb.update(new Order(id, clientID, productID, quantity));
            cmv.refresh();
        }
    }
    public class DeleteCommandListener implements ActionListener {
        /*public void actionPerformed(ActionEvent e) {
            int id = Integer.parseInt(cmv.getID());
            cmb.delete(id);
            cmv.refresh();
        }

         */
        public void actionPerformed(ActionEvent e) {
            String idText = cmv.getID();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID.");
                return;
            }
            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid ID. Please enter a numeric value.");
                return;
            }
            cmb.delete(id);
            cmv.refresh();
        }
    }
}

