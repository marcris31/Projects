package org.example.BusinessLogic;

import org.example.DataAccess.Product_DAO;
import org.example.Model.Client;
import org.example.Model.Product;

import java.util.List;
import java.util.NoSuchElementException;

public class Product_BLL extends Abstract_BLL{
    private final Product_DAO product_DAO;

    public Product_BLL() {
        product_DAO = new Product_DAO();
    }

    public List<Product> findAll() {
        List<Product> clientList = product_DAO.findAll();
        if (clientList == null) {
            throw new NoSuchElementException("No products were found");
        }
        return product_DAO.findAll();
    }

    public Product findByID(int id) {
        Product c = product_DAO.findByID(id);
        if (c == null) {
            throw new NoSuchElementException("No product was found");
        }
        return c;
    }

    public void insertInto(Product p) {
        if (!isEligibleProduct(p)) {
            throw new IllegalArgumentException("Not eligible product");
        }
        product_DAO.insertIntoTable(p);
    }

    public void update(Product p) {
        if (!isEligibleProduct(p)) {
            throw new IllegalArgumentException("Not eligible product");
        }
        product_DAO.updateTable(p);
    }

    public void delete(int id) {
        Product p = product_DAO.findByID(id);
        if (p == null) {
            throw new IllegalArgumentException("Not eligible product");
        }
        product_DAO.deleteFromTable(id);
    }

public String[] getColumns() {
        return product_DAO.getColumns();
    }

    public String[][] getValues() {
        try {
            return product_DAO.getValues();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    private boolean isEligibleProduct(Product p) {
        return p.getId() != 0 && p.getName() != null && p.getStock() > -1 && p.getPrice() > 0;
    }
}
