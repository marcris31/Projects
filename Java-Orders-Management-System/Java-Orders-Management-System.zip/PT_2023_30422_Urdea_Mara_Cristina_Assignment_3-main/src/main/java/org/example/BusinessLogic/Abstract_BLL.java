package org.example.BusinessLogic;

public class Abstract_BLL {
    public String[] getColumns() {
        return null;
    }

    public String[][] getValues() {
        return null;
    }
}
