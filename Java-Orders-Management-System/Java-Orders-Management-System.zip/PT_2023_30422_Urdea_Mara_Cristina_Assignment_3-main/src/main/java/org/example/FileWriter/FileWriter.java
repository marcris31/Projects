package org.example.FileWriter;

import org.example.BusinessLogic.Client_BLL;
import org.example.BusinessLogic.Order_BLL;
import org.example.BusinessLogic.Product_BLL;
import org.example.Model.Client;
import org.example.Model.Order;
import org.example.Model.Product;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;

public class FileWriter {
    public static void createTxtBill(Order o) {
        /*String pathname = "Order bill nr. " + o.getId()+ ".txt";
        File bill = new File(pathname);
        try {
            bill.createNewFile();
            if(bill.exists()) {
                bill.delete();
            }
            java.io.FileWriter writer = new java.io.FileWriter(bill);
            writer.write(o.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        String pathname = "Order bill nr. " + o.getId()+ ".txt";
        File bill = new File(pathname);
        try {
            bill.createNewFile();
            if(bill.exists()) {
                bill.delete();
            }
            java.io.FileWriter writer = new java.io.FileWriter(bill);


            writer.write("Order ID: " + o.getId() + System.lineSeparator());
            writer.write("Client ID: " + o.getIdClient() + System.lineSeparator());
            writer.write("Client name: " + new Client_BLL().findByID(o.getIdClient()).getName() + System.lineSeparator());
            writer.write("Client address: " + new Client_BLL().findByID(o.getIdClient()).getAddress() + System.lineSeparator());
            writer.write("Product ID: " + o.getIdProduct() + System.lineSeparator());
            writer.write("Product name: " + new Product_BLL().findByID(o.getIdProduct()).getName() + System.lineSeparator());
            writer.write("Product price: " + new Product_BLL().findByID(o.getIdProduct()).getPrice() + System.lineSeparator());
            writer.write("Quantity: " + o.getQuantity() + System.lineSeparator());
            writer.write("--------------------------------------------------" + System.lineSeparator());

            writer.write("Total price: " + (long) o.getQuantity() * new Product_BLL().findByID(o.getIdProduct()).getPrice() + System.lineSeparator());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
