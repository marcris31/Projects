package org.example;

import org.example.BusinessLogic.Client_BLL;
import org.example.BusinessLogic.Order_BLL;
import org.example.BusinessLogic.Product_BLL;
import org.example.Model.Client;
import org.example.Model.Order;
import org.example.Model.Product;
import org.example.Presentation.Controller;

import java.util.List;

public class Main {
    public static void main(String[] args) throws IllegalAccessException{
        Client_BLL client_bll = new Client_BLL();
        Product_BLL product_bll = new Product_BLL();
        Order_BLL order_bll = new Order_BLL();
        Client c = new Client(15, "Popescu Ion", "0748651123", "Cluj Napoca", "popescuion@yahoo.com");
        Product p = new Product(3, "Cana", 10, 100);
        Order o = new Order(5, 7, 3, 2);
        Controller controller = new Controller();

    }
}
