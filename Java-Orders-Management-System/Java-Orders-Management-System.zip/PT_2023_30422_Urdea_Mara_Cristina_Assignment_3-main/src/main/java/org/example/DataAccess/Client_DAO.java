package org.example.DataAccess;

import org.example.Model.Client;

import java.util.List;

public class Client_DAO extends Abstract_DAO<Client> {
    public boolean exists(int id) {
        List< Client > clientList = findAll();
        for (Client c: clientList) {
            if (c.getId() == id) return true;
        }
        return false;
    }
}
