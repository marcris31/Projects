package org.example.Presentation;

import org.example.BusinessLogic.Abstract_BLL;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Product_View extends JFrame {
    private JScrollPane sp;
    private JTable table;
    private JButton add;
    private JButton modify;
    private JButton delete;
    private JLabel id;
    private JTextField idTF;
    private JLabel name;
    private JTextField nameTF;
    private JLabel price;
    private JTextField priceTF;
    private JLabel stock;
    private JTextField stockTF;
    private Abstract_BLL ab;

    public Product_View(Abstract_BLL ab) {
        //construct preComponents
        this.ab = ab;
        initializeTable();

        add = new JButton ("Add");
        modify = new JButton ("Modify");
        delete = new JButton ("Delete ID");
        id = new JLabel ("ID:");
        idTF = new JTextField (5);
        name = new JLabel ("Name:");
        nameTF = new JTextField (5);
        price = new JLabel ("Price:");
        priceTF = new JTextField (5);
        stock = new JLabel ("Stock:");
        stockTF = new JTextField (5);

        //adjust size and set layout
        setPreferredSize (new Dimension(752, 420));
        setLayout (null);

        //add components
        add(sp);
        add (add);
        add (modify);
        add (delete);
        add (id);
        add (idTF);
        add (name);
        add (nameTF);
        add (price);
        add (priceTF);
        add (stock);
        add (stockTF);

        //set component bounds (only needed by Absolute Positioning)
        sp.setBounds(35, 150, 685, 250);
        add.setBounds (150, 100, 110, 20);
        modify.setBounds (275, 100, 100, 20);
        delete.setBounds (390, 100, 100, 20);
        id.setBounds (30, 20, 80, 25);
        idTF.setBounds (95, 20, 100, 25);
        name.setBounds (235, 20, 80, 25);
        nameTF.setBounds (320, 20, 100, 25);
        price.setBounds (450, 20, 85, 20);
        priceTF.setBounds (550, 20, 100, 25);
        stock.setBounds (235, 55, 85, 25);
        stockTF.setBounds (320, 55, 100, 25);

        setTitle("Product");
        pack();
        setVisible(true);
    }
    public void initializeTable() {
        String[] collumnNames = ab.getColumns();
        String[][] tableData = ab.getValues();
        table = new JTable (new DefaultTableModel(tableData, collumnNames));
        table.setModel(new DefaultTableModel(tableData, collumnNames));
        sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    public void refresh(){
        String[] collumnNames = ab.getColumns();
        String[][] tableData = ab.getValues();
        table.setModel(new DefaultTableModel(tableData, collumnNames));
    }

    public String getID() {
        return idTF.getText();
    }
    public String getName() {
        return nameTF.getText();
    }
    public String getPrice() {
        return priceTF.getText();
    }
    public String getStock() {
        return stockTF.getText();
    }

    public void addAddListener(ActionListener a) {
        add.addActionListener(a);
    }
    public void addModifyListener(ActionListener a) {
        modify.addActionListener(a);
    }
    public void addDeleteListener(ActionListener a) {
        delete.addActionListener(a);
        delete.addMouseListener(new DeleteListener());
    }

    class DeleteListener implements MouseListener {
        public void mouseEntered(MouseEvent event)
        {
            enableTextFields(false);
        }
        public void mouseExited(MouseEvent event)
        {
            enableTextFields(true);
        }
        public void mousePressed(MouseEvent event) { }
        public void mouseReleased(MouseEvent event) { }
        public void mouseClicked(MouseEvent event) { }
    }
    private void enableTextFields(boolean enabled) {
        idTF.setEnabled(enabled);
        nameTF.setEnabled(enabled);
        priceTF.setEnabled(enabled);
        stockTF.setEnabled(enabled);
    }
}

