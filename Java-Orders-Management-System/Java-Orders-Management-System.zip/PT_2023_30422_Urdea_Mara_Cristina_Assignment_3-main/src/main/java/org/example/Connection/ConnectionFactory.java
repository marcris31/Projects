package org.example.Connection;

import java.sql.*;
import java.util.logging.Logger;

public class ConnectionFactory {
    private  static final Logger LOGGER = Logger.getLogger(ConnectionFactory.class.getName());
    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String DRIVER = "org.postgresql.Driver";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Allegra~1";
    public static Connection getConnection;

    private static ConnectionFactory connectionFactory = new ConnectionFactory();

    private ConnectionFactory () {
        try {
            Class.forName(DRIVER);
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private Connection createConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            if(connection != null) {
                System.out.println("Connection established!");
            }
            else {
                System.out.println("Connection failed!");
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static Connection getConnection() {
        return connectionFactory.createConnection();
    }

    public static void close(Connection c) {
        try {
            c.close();
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    public static void close(ResultSet rs) {
        try {
            rs.close();
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    public static void close(Statement s) {
        try {
            s.close();
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }
}
