package org.example.DataAccess;

import org.example.Connection.ConnectionFactory;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This is a generic class that implements the basic CRUD operations.
 * From here is managed the connection to the database.
 * @param <T> can be Client, Product or Order
 */
public class Abstract_DAO <T> {
    protected static final Logger LOGGER = Logger.getLogger(Abstract_DAO.class.getName());
    private final Class<T> type;

    @SuppressWarnings("unchecked")
    public Abstract_DAO() {
        this.type = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    /**
     * This method creates the SELECT all query.
     * @return data if the query was successful, null otherwise
     */

    public List<T> findAll() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        sb.append(" * ");
        sb.append(" FROM ");
        sb.append("\"" + type.getSimpleName() + "\"");
        String query = sb.toString();
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();
            return createObjects(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(connection);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(resultSet);
        }
        return null;
    }


    public T findByID(int id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String query = createSelectWhereQuery(id);
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            return createObjects(resultSet).get(0);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findById " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    private String createSelectWhereQuery(int id) {
        StringBuilder sb = new StringBuilder();
        /*sb.append("SELECT ");
        sb.append("* ");
        sb.append("FROM ");
        sb.append(type.getSimpleName());
        sb.append(" WHERE ").append("id").append(" = ");
        sb.append(id);
        return sb.toString();*/
        sb.append("SELECT * FROM ");
        sb.append("\"" + type.getSimpleName() + "\"");
        sb.append(" WHERE id = ?");
        return sb.toString();
    }


    public void insertIntoTable (T table) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            String insert = createInsertIntoStatement(table);
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(insert);

            int i = 1;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                statement.setObject(i, field.get(table));
                i++;
            }

            statement.executeUpdate();
        } catch (SQLException | IllegalAccessException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(connection);
            ConnectionFactory.close(statement);
        }
    }

    /**
     * This method creates the INSERT INTO query.
     * @param table is the object that will be inserted into the database
     * @return the query
     */
    private String createInsertIntoStatement (T table) throws IllegalAccessException {
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO ");
        sb.append("\"" + type.getSimpleName() + "\"");
        sb.append(" (");
        StringBuilder values = new StringBuilder();
        values.append("VALUES (");
        for (Field field : type.getDeclaredFields()) {
            field.setAccessible(true);
            sb.append(field.getName()).append(", ");
            values.append("?, ");
        }
        sb.delete(sb.length() - 2, sb.length()); // Remove the extra comma and space
        values.delete(values.length() - 2, values.length()); // Remove the extra comma and space
        sb.append(") ").append(values).append(")");
        return sb.toString();
    }

    public void deleteFromTable (int id) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            String delete = createDeleteFromStatement(id);
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(delete);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method creates the DELETE FROM query.
     * @param id is the id of the object that will be deleted
     * @return the query
     */
    private String createDeleteFromStatement (int id) throws IllegalAccessException {
        StringBuilder sb = new StringBuilder();
        sb.append("DELETE FROM ");
        sb.append("\"" + type.getSimpleName() + "\"" );
        sb.append(" WHERE id = ");
        sb.append(id);
        return sb.toString();
    }

    /**
     * This method creates the UPDATE query.
     * @param table is the object that will be updated
     */

    public void updateTable (T table) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            String update = createUpdateStatement(table);
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(update);

            int i = 1;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                statement.setObject(i++, field.get(table));
                //i++;
            }
            Field field = type.getDeclaredFields()[0];
            field.setAccessible(true);
            statement.setObject(i++, field.get(table));
            statement.executeUpdate();
        } catch (SQLException | IllegalAccessException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(connection);
            ConnectionFactory.close(statement);
        }
    }

    /**
     * This method creates the UPDATE query.
     * @param table is the object that will be updated
     * @return the updated query
     */
    private String createUpdateStatement (T table) throws IllegalAccessException {
        StringBuilder sb = new StringBuilder();
        int id = 0;
        sb.append("UPDATE ");
        sb.append("\"" + type.getSimpleName() + "\"");
        sb.append(" SET ");
        int i = 1;
        for (Field field : type.getDeclaredFields()) {
            field.setAccessible(true);
            sb.append(field.getName());
            sb.append(" = ? , ");
            //sb.append(field.get(table));
            //sb.append(", ");
            i ++;
        }
        sb.delete(sb.length() - 2, sb.length());
        sb.append(" WHERE id = ?");
        //sb.append(id);
        return sb.toString();
    }

    /**
     * This method is using reflection to create a list of objects from the result set.
     * @param resultSet is the result set from the database
     * @return the generated list of objects
     */
    public List<T> createObjects(ResultSet resultSet) {
        List<T> list = new ArrayList<T>();
        try {
            while (resultSet.next()) {
                T instance = type.getDeclaredConstructor().newInstance();
                for (Field field : type.getDeclaredFields()) {
                    Object value = resultSet.getObject(field.getName());
                    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(field.getName(), type);
                    Method method = propertyDescriptor.getWriteMethod();
                    method.invoke(instance, value);
                }
                list.add(instance);
            }
        } catch (SQLException | IntrospectionException | IllegalAccessException | InvocationTargetException |
                 InstantiationException | NoSuchMethodException e) {
            e.printStackTrace();
        }
        return list;
    }


    public String[] getColumns() {
        List<String> columns = new ArrayList<String>();
        for (Field field : type.getDeclaredFields()) {
            field.setAccessible(true);
            columns.add(field.getName());
        }
        return columns.toArray(new String[columns.size()]); //0
    }

    /*public String[][] getValues() throws IllegalAccessException {
        int i = 0;
        List<T> objectList = findAll();
        if (objectList == null) {
            return new String[0][0];
        }
        String[][] values = new String[objectList.size()][type.getDeclaredFields().length];
        for (T object : objectList) {
            int j = 0;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                values[i][j] = String.valueOf(field.get(objectList.get(i)));
                j++;
            }
            i++;
        }
        return values;
    }*/

    public String[][] getValues() throws IllegalAccessException {
        List<T> objectList = findAll();
        if (objectList == null) {
            return new String[0][0];
        }
        String[][] values = new String[objectList.size()][type.getDeclaredFields().length];
        for (int i = 0; i < objectList.size(); i++) {
            T object = objectList.get(i);
            int j = 0;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                values[i][j] = String.valueOf(field.get(object));
                j++;
            }
        }
        return values;
    }

}
